# NameShot — Build Log

Chronological record of phases. Every entry states what was **actually run and observed**.

---

## Phase 0 — Repository and toolchain reconnaissance (2026-10-06)

### Repository

- `D:\Proyectos\NameShot` existed and was **empty** (0 files, not a git repository).
  Nothing to preserve; no unrelated files touched.

### Machine / OS

| Item | Observed value | Source |
|---|---|---|
| OS | Windows 10 IoT Enterprise LTSC, `Microsoft Windows NT 10.0.19044.0` (build 19041/19044) | `Get-CimInstance Win32_OperatingSystem`, `[Environment]::OSVersion` |
| Arch / CPU | x64, Intel Core i5-3470 @ 3.20 GHz, 4 cores | `Win32_Processor` |
| RAM | 16 270 MB | `Win32_ComputerSystem` |
| GPU | Intel HD Graphics | `Win32_VideoController` |
| GUI available? | **Yes** — session 1, `explorer.exe` running (PID observed) | `SessionId`, `Get-Process explorer` |
| PowerShell | 5.1 (Windows PowerShell) | `$PSVersionTable` |
| Language | Spanish Windows (messages localized; logs keep English) | observed |

Conclusion: this machine **can run and be measured with a real Windows GUI**, so Windows-specific
behaviour (tray, hotkey, overlay, editor, clipboard, dialogs) can be exercised directly.

### Toolchain state at start

- `rustc`, `cargo`, `rustup`: **not installed** (not on PATH, `~/.cargo/bin` absent).
- Visual Studio / MSVC (`vswhere.exe`, `link.exe` from MSVC): **not installed**.
- `winget`, `choco`, `scoop`: not available. `gcc`/`clang`: not present anywhere on disk.
- `git`: available (`C:\Program Files\Git\cmd\git.exe`).
- Network: reachable. Measured throughput is low (≈50–110 KB/s to most hosts), so the toolchain
  was chosen to minimise download size.

### Toolchain installed (during Phase 0)

1. `rustup-init.exe -y --default-toolchain stable --default-host x86_64-pc-windows-gnu --profile minimal`
   (first run was interrupted → toolchain reported `missing manifest`; fixed with
   `rustup toolchain install stable --profile minimal`).
   - **Verified:** `rustc 1.99.0 (b940084d7 2026-09-28)`, `cargo 1.99.0 (5f94df478 2026-08-27)`,
     host `x86_64-pc-windows-gnu`; components present: `rustc`, `cargo`, `rust-std`, `rust-mingw`,
     `rustfmt`, `clippy`, `rust-docs`.
2. MinGW-w64 (needed as the linker for the GNU host): winlibs
   `x86_64-posix-seh-gcc-16.2.0-mingw-w64ucrt-14.0.0` zip (274 MB) downloaded from the official
   GitHub release to `%TEMP%\opencode\nameshot-setup\mingw.zip` (resumed with `curl -C -`).
   - Rationale: MSVC route requires Visual Studio Build Tools + Windows SDK (~5 GB) and none are
     installed; MSYS2 mirrors measured ≈50 KB/s; GitHub release measured ≈110 KB/s.
   - Verification of the installed gcc is recorded in Phase 1.

### Decisions taken in Phase 0

- **Language/toolchain:** stable Rust, `x86_64-pc-windows-gnu` host/target, `windows` crate for
  Win32. (Material environment constraint — no MSVC on the machine; documented here because it
  affects build commands in the README.)
- **Architecture** written to `docs/ARCHITECTURE.md` *before* substantial implementation:
  module boundaries, Win32 API choices (GDI one-shot capture vs DXGI evaluation, WIC encoding,
  CF_DIB clipboard, IFileSaveDialog, INI settings), redaction-correctness model, dependency policy
  (only the `windows` crate).
- **No unsupported platform assumptions:** the app is Windows-first; cross-platform code is only
  the OS-free core, and no untested platform claim will be made.

### Exit criteria (Phase 0)

- [x] Repository structure and build environment understood.
- [x] `docs/ARCHITECTURE.md` written before implementation.
- [x] OS is Windows 10 x64 with GUI → Windows behaviour will be actually run, not simulated.

---

## Phase 1 — OS-free core (2026-10-06 → 2026-10-07)

### Implemented

Pure-Rust, no-Win32 modules (unit-testable without a GUI session):

| Module | Responsibility |
|---|---|
| `strings.rs` | All user-facing text (EN), `fill()` placeholder substitution |
| `error.rs` | `AppError` type + OS-error formatting |
| `image/mod.rs` | `Frame` (BGRA), `IRect`, `VirtualScreen`, geometry/colour helpers |
| `image/redact.rs` | Redaction/blur primitives operating only on raw pixels |
| `annotate.rs` | Shapes, pen, highlight, text layout model (renderer-agnostic) |
| `flatten.rs` | Annotation → pixel rasterisation over a `Frame` |
| `config.rs` | `Settings` model + INI load/save (`%APPDATA%\NameShot\settings.ini`) |
| `hotkey.rs` | `HotkeySpec`, modifiers, key names, Win32 registration **format** logic |
| `output.rs` | Save-dir resolution, unique filenames, format selection |

### Actually run and observed

```
$ cargo test
test result: ok. 46 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.02s
```

- Exit code 0; 46/46 tests pass (2026-10-07, re-run after UI code was added: still 46/46).
- `cargo check --all-targets` also compiles the `#[cfg(test)]` targets: clean.

### Exit criteria (Phase 1)

- [x] Core logic implemented with no `windows`-crate dependency in the modules above.
- [x] `cargo test` green (46 passed / 0 failed), reproduced on a later run.

---

## Phase 2 — Windows layer and full application UI (2026-10-06 → 2026-10-07)

### Implemented

| Module | Responsibility |
|---|---|
| `win/gdi.rs` | `this_module()`, pens/brushes/fonts, `draw_label`, stock objects |
| `win/dark.rs` | DWM dark titlebar, shared `COLORREF`s, window-background brushes |
| `win/hotkey.rs` | `RegisterHotKey`/`UnregisterHotKey` + conflict detection |
| `win/clipboard.rs` | CF_DIB copy / paste |
| `win/tray.rs` | `Shell_NotifyIconW` add/modify/delete + context menu |
| `win/dialog.rs` | `IFileSaveDialog`, folder picker, message boxes |
| `win/mod.rs` | module glue, `wide()` UTF-16 helper |
| `capture.rs` | GDI `BitBlt` one-shot capture of the virtual screen |
| `encode.rs` | WIC PNG/JPEG/WEBP encode, `get_dibits`-based decode |
| `text.rs` | DirectWrite-ish GDI text measurement for the editor |
| `os.rs` | Windows 10/11 detection, paths |
| `app.rs` | `App` state, tray hotkey dispatch, capture/save/exit flows, single `GetMessage` loop, custom message prefilter, window-class registration, fonts |
| `overlay.rs` | Full-screen capture overlay: rubber-band selection, handles, pan/resize, keyboard |
| `editor/mod.rs` | Dark editor: tools, colour/width strip, history (undo/redo), zoom/pan, text-edit child, status bar, save/copy |
| `editor/toolbar.rs` | Custom-painted vertical tool strip + colour/width controls |
| `settings_ui.rs` | Modeless Settings window, hotkey-capture window, About window |

### Actually run and observed (2026-10-07)

```
$ cargo check --all-targets   # exit 0, 0 errors, 0 warnings
$ cargo test
test result: ok. 46 passed; 0 failed; ...
$ cargo build
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 2.08s
→ target\debug\nameshot.exe, 20 445 159 bytes
```

Full warning sweep done in this phase: **0 errors / 0 warnings** after fixing every
`unused BOOL` (`InvalidateRect`/`EnableWindow`/`Ellipse` results now bound with `let _ =`),
private-type-in-public-interface (`Drag`/`ODrag` → `pub`), unused imports/consts/params.

### Technical findings recorded during Phase 2

- `windows` 0.62: `SendMessageW`/`PostMessageW` take `Option<WPARAM>`/`Option<LPARAM>`;
  `SetForegroundWindow`, `EnableWindow`, `InvalidateRect`, `Ellipse` return must-use `BOOL`.
- `RefCell<Option<T>>::borrow().map(...)` fails with E0507 (moves out of `Ref`) →
  must be `.borrow().as_ref().map(...)`; the compiler suggestion is reliable.
- Edition 2024: unsafe ops inside `unsafe fn` (our Win32 wndprocs) are **warnings** by default
  (`unsafe_op_in_unsafe_fn`) but hard **errors** (E0133) inside *safe* fns → each such call site
  in safe code was wrapped in `unsafe { }`. Crate-level `#![allow(unsafe_op_in_unsafe_fn)]`
  documents the wndproc convention.
- Custom window classes must pass `Some(this_module())` as `hinstance`, otherwise
  `LoadIconW`/cursor lookups silently fall back to the exe module of the *other* process.
- Message prefilter design finalised: keyboard messages only; hotkey-capture window redirects
  `msg.hwnd` to its root (it reads raw keys itself); Settings/About delegate to
  `IsDialogMessageW(root, msg)` which uses `WM_GETDLGCODE` and posts `IDOK`/`IDCANCEL`
  (mapped to `CMD_OK`/`CMD_CANCEL` = 1/2).

### Exit criteria (Phase 2)

- [x] All planned modules implemented; `cargo check --all-targets` clean (0/0).
- [x] `cargo build` links `nameshot.exe`.
- [ ] GUI behaviour (tray, hotkey, overlay, editor, settings, clipboard, save) — **not yet
      exercised**; deferred to Phase 3, no claim of working UI is made here.

---

## Phase 3 — Live GUI verification on the real machine (2026-10-07)

### Test approach

Interactive but hands-off: windows were driven with `PostMessageW`/`SendMessageW` (packed
`lParam=(y<<16)|x` for coordinates) and `keybd_event` only while one of *our* windows/menus
had focus; **no cursor movement, no mouse clicks**. Screenshots taken passively with GDI
`CopyFromScreen` from a separate PowerShell process (`SetProcessDPIAware()` first) — verified
this session to return live pixels (fresh capture matched wall clock exactly).

Scripts (in `%TEMP%\opencode`): `ns_save.ps1` (dedicated save-path probe) and `ns_phase3.ps1`
(canonical A–K sequence; `ns_diag.ps1` was an earlier instrumented attempt, superseded).

Message IDs used: `WM_HOTKEY=0x0312` (wParam `0x4E53`) to `NameShot.Main`, tray callback
`WM_APP_TRAY=0x8001` lParam `0x205` (activate → menu), `WM_CLOSE=0x0010`, `WM_KEYDOWN=0x0100`,
mouse `WM_MOUSEMOVE/LBUTTONDOWN/LBUTTONUP` for the rubber band.

### A–K sequence — final run (13:07:20 → 13:07:31, process exit code 0)

| Step | Action | Observed |
|---|---|---|
| A | Launch `nameshot.exe` | Main window class `NameShot.Main` found, PID recorded, **no console window** |
| B | `PostMessage(WM_HOTKEY)` | Capture overlay window appears, full-screen |
| C | `WM_LBUTTONDOWN (600,300) → WM_MOUSEMOVE (1500,850) → WM_LBUTTONUP` | Teal rubber band + 8 handles + hint strip visible in `p3_c_region.png` |
| D | `WM_KEYUP VK_RETURN` | Editor opens with the 901×551 region; overlay destroyed |
| E | `Ctrl+C` (real `keybd_event`, editor foreground) | Clipboard contains `CF_DIB`, size **1 985 844 B** |
| F | `Ctrl+S` | **"Guardar como" dialog (`#32770`, pid-filtered) found; default filename `NameShot_2026-10-07_130723` selected; Enter → saved**: file count 0→1 |
| G | After save | Editor not dirty (save clears it); `p3_f_savedialog.png` shows the dialog + `Copied to clipboard` status + clock 13:07 (matches run exactly); in-app success status `Saved: NameShot_2026-10-07_130723.png` confirmed in the `ns_save` run |
| H | Tray menu via `PostMessage(hwnd, WM_APP_TRAY, 0, 0x205)` | Menu `#32768`: Capture / sep / Settings / About / sep / Exit; `Down,Down,Enter` → **Settings window opened** |
| I | `Esc` in Settings | Closed by prefilter (`IsDialogMessageW` path), app still running |
| J | Tray → `Down,Down,Down,Enter` → **About**, `Esc` | About window opened and closed |
| K | Tray → Exit | Process exited cleanly, **no panic file** |

Saved file verified independently: **162 182 B, 901×551, valid PNG** (decoded with
`System.Drawing`), then deleted — `Pictures` folder left empty (test files are removed after
verification, per privacy rule).

### Independent save-path verification (`ns_save.ps1`, 12:42 run)

Because detection bugs had previously made step F ambiguous, a dedicated script retried the
whole Ctrl+S path with EnumWindows-based dialog polling and a post-Enter screenshot:

- Dialog `dialog=2888088` found, `dialog_still_open=False` after Enter.
- `p3s_b2_postenter.png` status bar reads **`Saved: NameShot_2026-10-07_124218.png`** —
  success path observed end-to-end in the app's own UI.
- File created (before=0 → after=1), clean exit, no panic; file deleted afterwards.

### Bugs found in this phase (all fixed, verified by re-run)

| # | Bug | Fix |
|---|---|---|
| 1 | `encode_to_file` produced **0-byte PNGs**: `CreateNewFrame` was not followed by `frame_enc.Initialize(&bag)` → `SetSize` failed with `WINCODEC_ERR_PROPERTYNOTINITIALIZED (0x88982F0C)` | `src/encode.rs`: initialize the frame encoder with the properties bag; bag now unwrapped with `ok_or_else` |
| 2 | `encode_png_bytes` cast the HGLOBAL shell stream to `IWICStream` → `E_NOINTERFACE (0x80004002)` (shell streams don't implement `IWICStream`) | pass a plain `IStream` to `encode_into` (encoders accept it); `decoder_from_bytes` now uses `fac.CreateStream()` + `InitializeFromMemory` |
| 3 | `IFileSaveDialog` worked but the process never called `CoInitialize[Ex]` — behaviour relied on an unexplained implicit init | explicit `CoInitializeEx(None, COINIT_APARTMENTTHREADED)` at the top of `app::run()` (all results incl. `RPC_E_CHANGED_MODE` ignored); test helpers call the same |

A regression test was added: **`tests/encode_roundtrip.rs`** — 4 integration tests
(PNG/JPEG/BMP `encode_to_file` → non-empty → `decode_file` round-trip; `encode_png_bytes`
signature + round-trip), each with its own `init_com()`.

```
$ cargo test        → 46 unit + 4 integration = 50 passed, 0 failed
$ cargo check --all-targets → exit 0, 0 warnings (re-confirmed 13:15)
$ cargo build       → target\debug\nameshot.exe rebuilt clean
```

### Test-harness findings (PowerShell, not app bugs)

- `Write-Output` **inside an `EnumWindows` callback delegate is silently lost** → collect into
  a `$script:` list, flush after the call.
- `FindWindowExW(Zero, Zero, '#32770', $null)` never matches titled dialogs in PS → EnumWindows
  + `GetClassNameW` + pid filter (`FindOurDlg`) instead.
- Structs declared inside `-MemberDefinition` are nested: `New-Object D2.W+RECT`.
- PowerShell functions emit all output: assigning `$x = Wait-Function` captured status strings
  alongside the handle → poll loops must write status to `$script:` or `[void]`.
- `Set-Content`/heredocs corrupted scripts earlier — edits done with the file-edit tool from
  then on.

### Hotkey note

Default hotkey `PrintScreen` (`RegisterHotKey` with no modifiers) intermittently fails with
**error 1409 `ERROR_HOTKEY_ALREADY_REGISTERED`** — explorer's snipping hook holds the key.
Registering with `MOD_ALT` succeeds. Explorer still holds plain PrintScreen on this machine,
so the *global* registration could not be observed here; the handler path was exercised by
posting `WM_HOTKEY` directly (step B), which is the same code path a registered hotkey fires.
Settings UI allows changing the hotkey; conflict detection reports the failure.

### Screenshot inventory (in `%TEMP%\opencode`, final run)

`p3_b_overlay`, `p3_c_region`, `p3_d_editor`, `p3_f_savedialog` (dialog + correct default
filename + clock 13:07), `p3_h_menu`, `p3_i_settings`, `p3_j_about` — plus `p3s_*` from the
independent save run (editor, dialog, post-Enter "Saved:" status, after-save). Earlier
`p3x_*`/`p3s_c_statusbar` files are from superseded runs kept for comparison; resolved as
harness detection issues, not application defects.

### Exit criteria (Phase 3)

- [x] Tray, hotkey path, overlay, region selection, editor, clipboard, native Save dialog,
      Settings, About, clean exit — all exercised live on Windows 10 x64 (A–K pass).
- [x] Every defect found was a real bug; fixed and covered by tests (50 green).
- [x] No unverified UI claim: screenshots for each step retained; save verified twice
      (file bytes + in-app status message).
- [ ] Global `PrintScreen` registration — blocked by explorer's own hotkey (1409);
      handler verified via posted `WM_HOTKEY`. Documented, not claimed.

---

## Phase 4 — Icon embedding, README (2026-10-07)

### Implemented

| File | Purpose |
|---|---|
| `build.rs` | Embeds `assets/icon.ico` as Win32 resource `1 ICON` into the exe. Windows-only: returns immediately when `CARGO_CFG_TARGET_OS != "windows"`. Writes `nameshot.rc` to `OUT_DIR`, compiles it with `x86_64-w64-mingw32-windres`/`windres` (GNU) or `rc.exe` (MSVC), then links the object via `cargo:rustc-link-arg-bins`. Missing icon or missing compiler → one `cargo:warning`, build continues (default icon kept). Emits `cargo:rerun-if-changed=assets/icon.ico` so replacing the file alone re-triggers the build. No new crate dependencies (pure `std`). |
| `assets/icon.ico` | **TEMPORARY placeholder** — 4 PNG-compressed frames (16/32/48/256 px, 32-bit alpha) generated from the draft `assets/icon.png`. To be replaced with the final `.ico` at the same path; no code changes needed afterwards. |
| `assets/make_placeholder_icon.ps1` | Regenerates `icon.ico` from a PNG (System.Drawing high-quality downscale → ICO container). Prints a TEMPORARY notice when run. |
| `README.md` | Project overview, verified-status table, feature list as actually implemented, build instructions (with the exact PATH line used on this machine), icon replacement procedure, hotkey caveat, layout. |

### Actually run and observed (2026-10-07)

Build-script guard, exercised by compiling `build.rs` standalone (`rustc --edition 2024`,
exit 0) and running the binary under controlled environments:

| Scenario | Result |
|---|---|
| `CARGO_CFG_TARGET_OS=unix`, `OUT_DIR` deliberately invalid | exit **0**, no output (early return; no `OUT_DIR` access) |
| `CARGO_CFG_TARGET_OS` unset | exit **0**, no output |
| `=windows`, valid `OUT_DIR`, `windres` **not** on PATH | exit **0**, prints `cargo:warning=no resource compiler …` |
| real cargo build (windres on PATH) | exit **0**, artifacts produced |

Icon embedding verified end-to-end on the real build:

```
$ cargo build
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 10.77s   (exit 0)
OUT_DIR\nameshot.rc       25 B    (generated: 1 ICON "assets/icon.ico")
OUT_DIR\nameshot_icon.o    50 060 B (windres COFF object, linked into the exe)
target\debug\nameshot.exe  20 589 797 B (rebuilt 14:13:19)
```

`[System.Drawing.Icon]::ExtractAssociatedIcon('target\debug\nameshot.exe')` returns
**the placeholder artwork** (dark rounded square, blue selection brackets, white pen) —
saved as `p4_exe_icon.png` and inspected visually: the resource is inside the executable,
not just on disk. (Windows picks the first icon group for Explorer/taskbar/Alt-Tab; the
tray icon is drawn programmatically and unchanged.)

Placeholder ICO self-check: `System.Drawing.Icon` loads it (32×32 default), header
`type=1 count=4`, each frame's first bytes are the PNG signature `89 50 4E 47`.

### Checks run (exact results)

| Command | Result |
|---|---|
| `rustfmt --edition 2024 --check build.rs` | **exit 0** (new file is rustfmt-clean) |
| `cargo fmt --all -- --check` | **exit 1**: 169 diff hunks in **25 pre-existing files** — the codebase was written without rustfmt and was never formatted (true before Phase 4; verified the count before/after: 26 files initially, `build.rs` fixed, 25 remain). **Deliberately not reformatting** the verified Phase 2/3 sources in a Phase-4-only change; a whole-repo `cargo fmt` is a candidate for a later phase with a full re-test. |
| `cargo check --all-targets` | **exit 0**, `Finished dev profile … in 3.51s`, 0 errors / 0 warnings |
| `cargo test` | **exit 0**: 46 unit + 4 integration passed, 0 failed (`Finished test profile … in 10.45s`) |
| `cargo build` | **exit 0**, 10.77s, exe rebuilt with embedded icon (above) |

### Notes

- Privacy claim checked: source search for `Ws2_32|WinHttp|WinInet|InternetOpen|URLMon|
  Win32_Networking|socket` → **no matches**; `Cargo.toml` still has exactly one dependency
  (`windows`). This backs the README's "no network code" statement.
- README documents the placeholder explicitly: path `assets/icon.ico`, expected format
  (multi-size `.ico`, 16/32/48/256, 32-bit with alpha), regeneration command, and the
  build-script behaviour when the icon or a resource compiler is absent.
- Known non-blocking item carried over: repo-wide rustfmt divergence (see table above).

### Exit criteria (Phase 4)

- [x] Icon embedded and visually verified inside `nameshot.exe`; replace-later workflow
      needs only a new `assets/icon.ico` (+ `cargo build`), zero code changes.
- [x] Resource embedding guarded: non-Windows run of the build script exits 0 without
      touching any Windows tool; missing windres/rc.exe degrades to a warning.
- [x] README.md written from actual state; no claim beyond what Phases 0–3 verified.
- [x] Checks executed and reported exactly: fmt (new file clean; repo-wide pre-existing
      divergence documented), check 0/0, test 50/0, build 0.

---

## Plan reconciliation (2026-10-07) — numbering and scope authority

### Which plan is authoritative

The **original phased execution plan** (heading `# Phased execution plan`, Phases 0–6)
issued in the project's first requirement message is **authoritative** for phase
numbering, scope, and acceptance criteria. On 2026-10-07 a numbering conflict was
reported: the redaction-test entry below was labelled "Phase 5", but the original plan
reserves Phase 5 for *Settings, polish, and performance*. The plan had not been persisted
in the repository; on 2026-10-07 it was recovered **verbatim** from the opencode session
store (`opencode.db`) and is summarised below. From this point on, phase numbers in this
log refer to the original plan unless an entry is explicitly labelled "executed phase".

Two numbering schemes exist and both are legitimate:

| Scheme | Where | Meaning |
|---|---|---|
| Original plan (authoritative) | first requirement message; summarised below | Phases 0–6 as contracted |
| Executed-phase numbering | this BUILD_LOG, Phases 0–4 / 4.5 | chronological batches actually built |

They diverged early: execution was re-batched (the OS-free core and the Windows UI were
built as executed Phases 1–2 instead of the original per-feature Phases 1–4, and an
icon/README batch had no original counterpart). The executed numbering is kept as the
historical record of *when* work happened; **what a phase must achieve is defined only by
the original plan**.

### Original plan ↔ this log

| Original plan phase | This log | State |
|---|---|---|
| 0 — Repository and toolchain reconnaissance | Phase 0 | done |
| 1 — Minimal native shell and tray lifecycle | executed Phases 1–3 (built together, live-verified in Phase 3) | done (both criteria met, see below) |
| 2 — Screen capture and selection overlay | executed Phases 1–3 (+ Esc-cancel live in Phase 6) | done; doc gap closed in Phase 6, multi-monitor still untested |
| 3 — Native editor and annotations | executed Phases 1–3 (+ mosaic/solid live in Phase 6) | implemented + unit-tested; per-tool live pass still open |
| 4 — Privacy redaction and output | executed Phases 1–3 + **Phase 4.5** (its item 2) + Phase 6 | tests + copy/save + live redaction verified; `Ctrl+Z`/`Ctrl+Y` still unverified |
| (no counterpart) — icon embedding + README | Phase 4 | done (README also required by the plan) |
| **5 — Settings, polish, and performance** | **Phase 5 (original numbering)** | done — live-verified 2026-10-07 |
| **6 — Verification, packaging, and delivery** | **Phase 6 (original numbering)** | done — live-verified 2026-10-07, 31/31 checks |

### Original acceptance criteria — final status

**Still open (the only two):** the live per-tool editor pass with undo/redo (Original
Phase 3) and the live `Ctrl+Z`/`Ctrl+Y` check (Original Phase 4) — both re-scoped with
their real current state below. Everything else was completed and ticked across Phases
4.5–6; nothing from the test-only Phase 4.5 was counted toward other phases' criteria.

**Original Phase 1**
- [x] "release build starts" — **complete as of Phase 5** (`cargo build --release` exit 0,
      exe 2,084,859 B; the live Phase 5 verification ran exclusively against it).
- [x] "idles without polling" — blocking `GetMessage` loop, and Phase 5 measured idle at
      0.000 CPU seconds over 20 s (~0% of one core), 0 sockets.

**Original Phase 2**
- [x] "document any unverified multi-monitor/DPI scenarios" — **complete as of Phase 6**:
      the machine is single-monitor 1920×1200; multi-monitor offsets and mixed-DPI
      desktops remain untested, and the gap is now recorded in README ("Known
      limitations" + the last QA-checklist line) and in the Phase 6 entry below.

**Original Phase 3**
- [ ] "each tool visibly works" / "undo/redo is correct" live in the editor window —
      Phase 3 verified capture→editor→copy/save only; **Phase 6 added live passes of the
      mosaic and solid tools** (property-verified output, two full sessions) plus live
      toolbar navigation (Tab/Enter). Still not live-exercised: pen/line/arrow/rect/
      box/text/highlight and `Ctrl+Z`/`Ctrl+Y` (undo/redo is implemented at
      `src/editor/mod.rs:859/:862` with 3 dedicated unit tests in `annotate.rs`;
      rendering correctness of every tool is covered by unit/integration tests).

**Original Phase 4**
- [ ] Live verification of `Ctrl+Z`/`Ctrl+Y` — both are implemented
      (`src/editor/mod.rs:859`, `:862`); Phase 3 exercised only `Ctrl+C`/`Ctrl+S`,
      Phase 6 added `Ctrl+C`/`Ctrl+S` in two more sessions (copy==save pixel-identical).
- [x] Item 2 — "automated tests proving the exported output does not preserve original
      pixels in redacted regions or hidden layers" — **complete as of Phase 4.5 below**
      (this is what that test-only phase delivered; it was never a Phase 5 criterion).

**Original Phase 5 — Settings, polish, and performance — complete as of Phase 5 below
(2026-10-07)**
1. [x] Versioned settings file; invalid/missing settings validated and recovered to safe
       defaults — live-verified: S1 persistence round-trip, S2 corrupt-file recovery
       (all 7 corrupt values fell back to safe defaults).
2. [x] Configurable hotkey and output folder/format; startup-on-login off unless the user
       enables it — audited (HKCU `Run` written only on explicit enable, default off)
       and live-verified end-to-end (change → persist → restart → read back).
3. [x] Polish dark/minimal interface, error messages, keyboard states, accessibility
       names — audited (no defects found) + new `src/win/a11y.rs` exposes
       `PROPID_ACC_NAME` on four controls, verified live via MSAA `accName`.
4. [x] Release build with measured idle CPU / private working set / peak capture-session
       memory, no benchmark loop inside the app, conditions recorded — done, exact
       numbers and conditions in the Phase 5 entry.
5. [x] Verify no network access, analytics, auto-upload, or hidden capture history —
       formalised in the Phase 5 entry (`cargo tree`, code-path audit, live socket
       counts in three states).
- Exit criteria — settings survive restart; defaults privacy-safe; idle process
  quiescent; reported measurements real and reproducible: **met, all four checked in
  the Phase 5 entry**.

**Original Phase 6 — Verification, packaging, and delivery — complete as of Phase 6 below
(2026-10-07)**
- [x] Item 1 — formatting/lint/all tests/release build; fix warnings that indicate
      correctness, safety, or resource problems: all five gates re-run fresh (table in
      the Phase 6 entry). Clippy shows only style/docs-level findings (classified, no
      correctness/safety/resource warnings); `cargo fmt --check` divergence (169 blocks
      in 25 pre-existing files) recorded instead of rewriting formatted code — both per
      plan wording, nothing to fix.
- [x] Item 2 — review unsafe code, resource cleanup, hotkey conflicts, clipboard
      ownership, DPI arithmetic, redaction export paths: findings table in the Phase 6
      entry (no defects found; every export path funnels through flatten→redact).
- [x] Item 3 — complete README, ARCHITECTURE, BUILD_LOG + concise manual QA checklist:
      README gained Running/package, measured resources, the 10-item QA checklist,
      Known limitations and Troubleshooting; ARCHITECTURE module table drift fixed;
      BUILD_LOG updated (this entry + reconciliation).
- [x] Item 4 — separate passed automated/core checks from manual checks still required:
      Windows-specific execution was available, so every runnable check was run live;
      the remaining unverified items (multi-monitor, mixed-DPI, DRM, live per-tool
      editor pass) are listed explicitly in the Phase 6 entry and README.
- [x] Item 5 — honest final summary: Phase 6 entry §7 below; no perfect-optimization or
      universal-compatibility claims.
- [x] The 8-box final acceptance checklist — ticked with per-box evidence in the Phase 6
      entry §7 below (7 of 8 fully met; the editor box stays open because the live
      per-tool/undo-redo pass of original Phase 3 was never done).

### PrintScreen conflict and fallback (kept prominent, unchanged)

Windows/explorer may already hold bare `PrintScreen` (snipping hook): `RegisterHotKey`
fails with error 1409 and NameShot reports *hotkey unavailable* while staying running.
**Fallbacks: capture from the tray menu, or set `Alt+PrintScreen` (or any other hotkey)
in Settings.** Also documented in README ("Hotkey note").

---

## Phase 4.5 — Redaction-correctness tests (2026-10-07, executed-phase numbering)

Fulfils **original plan Phase 4, item 2** (not original Phase 5 — see the Plan
reconciliation above). Renamed from "Phase 5" on 2026-10-07 when the numbering conflict
was found.

### Scope confirmation (checked before any work)

`README.md` and `docs/BUILD_LOG.md` define no phase after Phase 4. The only phase-like
work item documented anywhere in the repository is the redaction test suite promised by
`docs/ARCHITECTURE.md` ("Redaction correctness model", point 4): a file `tests/redaction.rs`
that "proves this on synthetic images" with four stated assertions — **but the file did not
exist** (`tests/` contained only `encode_roundtrip.rs`). Confirmed with the user via a
question (options: implement that file / restate the original plan / release-build phase);
the confirmed scope is exactly `tests/redaction.rs` below. No other work was invented; the
temporary icon and the pre-existing (unformatted) sources were not touched.

### Implemented

`tests/redaction.rs` — one integration test per ARCHITECTURE assertion:

| Test | Acceptance criterion (`docs/ARCHITECTURE.md`) |
|---|---|
| `mosaic_output_equals_block_means_and_contains_no_original_values` | "mosaic output equals block averages and contains no original per-pixel values" |
| `solid_output_is_fully_opaque` | "solid output is fully opaque" |
| `flatten_differs_from_source_only_inside_redaction_regions` | "flattened output differs from source only inside redaction regions" |
| `encode_decode_roundtrip_equals_flattened_buffer` | "encode → decode round-trip equals the flattened buffer byte-for-byte" |

Design: the synthetic source has **every colour channel even**, arranged per 4×4 cell as
`base, base+2, …, base+30`, so each cell mean is `base + 15` (odd) — a redacted value can
never coincide with an original one. The mosaic test asserts both per-pixel equality with
the independently computed mean (same rounding as `redact::pixelate`: `(sum + n/2)/n`) and
an **empty intersection** between original and output RGB value sets. The solid test uses a
translucent source (alpha 17) and translucent colour (alpha 42) to prove alpha is forced to
255 while the outside region stays untouched. The round-trip test exercises the editor's
real save path (`encode_to_file` PNG → `decode_file`, COM initialized as in
`tests/encode_roundtrip.rs`) over a mixed annotation list (rect + pen + mosaic + solid).

### Actually run and observed (2026-10-07)

| Command | Result |
|---|---|
| `rustfmt --edition 2024 --check tests/redaction.rs` | **exit 0** (file formatted with rustfmt; no other file reformatted) |
| `cargo check --all-targets` | **exit 0** |
| `cargo test` | **exit 0 — 54 passed, 0 failed**: 46 unit + 4 `encode_roundtrip` + 4 `redaction` (+ 0 doc); the new suite passed on its first execution |

### Exit criteria (Phase 4.5)

- [x] All four ARCHITECTURE assertions exist as executable tests and pass.
- [x] Phase 3/4 outputs, temporary icon, and pre-existing sources preserved unchanged
      (only `tests/redaction.rs` added; `README.md` status row/test count/layout line
      updated so documented numbers stay true; this entry appended).
- [x] Exact results recorded; no issues found in the code under test.
- [ ] Carried over unchanged (out of scope): repo-wide rustfmt divergence (25 pre-existing
      files), bare `PrintScreen` registration blocked by explorer's snipping hook.

---

## Phase 5 - Settings, polish, and performance (2026-10-07, original plan numbering)

Original plan items: (1) versioned local settings file with invalid/missing recovery,
(2) configurable hotkey/output folder/format, startup-on-login off unless explicitly
enabled, (3) polish interface/error messages/keyboard states/accessibility names,
(4) release build + measured idle CPU/private working set and peak capture-session
memory with recorded conditions and no benchmark loop inside the app, (5) verify no
network/analytics/auto-upload/hidden capture history. Exit criteria: settings survive
restart, defaults privacy-safe, idle quiescent, measurements real and reproducible.

### 1-2. Settings persistence, recovery, launch-at-login (audited + live-verified)

Items 1-2 were implemented in Phase 2; this phase audited and live-verified them.

- `src/config.rs`: versioned INI (`version=1`), tolerant parse (unknown keys, out-of-range
  values, wrong types, foreign version all fall back to safe defaults), atomic save
  (`write tmp + rename`), 8 unit tests, and it stores **no pixel data** ever.
- `src/hotkey.rs` + Settings window: hotkey and output folder/format configurable;
  `launch_at_login` written only to `HKCU\...\Run` via `src/os.rs` (`startup_entry`),
  default **off**, with the visible hint "Off by default. Never overwrites an existing file."
- Live `S1` (persistence round-trip) and `S2` (corrupt-file recovery): see table below.

### 3. Polish and accessibility names (implemented this phase)

- Error messages (`src/strings.rs`) and keyboard states (editor `on_key`: Ctrl+C/S/Z/Y,
  Tab cycles toolbar focus, Esc discards pending text; toolbar is a custom-drawn strip,
  so no native focus states apply) audited - no defects found.
- **New `src/win/a11y.rs`**: `set_name(hwnd, name)` uses `IAccPropServices`
  (`CLSID_AccPropServices`, `SetHwndPropStr`, `PROPID_ACC_NAME`) on **both** object ids
  (`OBJID_CLIENT` and `OBJID_WINDOW`), best-effort (`let _ =`, never blocks the UI).
  Cargo feature `Win32_UI_Accessibility` added. Call sites: Settings format combo
  ("Image format"), JPEG quality edit ("JPEG quality"), save-folder edit ("Save folder"),
  editor inline text input (`s().text_input_name` = "Text input", new `strings.rs` field).
- **Verified via MSAA** (`AccessibleObjectFromWindow` -> `accName`), which is the API the
  property-services override feeds: all four controls return exactly the set names
  (live run, see table). The .NET UIA client on this OS build reports the control's text
  through its native UIA provider instead of the `PROPID_ACC_NAME` override (observed on
  ComboBox/Edit alike, also with `OBJID_WINDOW` set) - a Windows UIA/MSAA interop quirk,
  not an application defect; every control additionally has a visible text label, so both
  client families receive a name. Live assertions therefore read `accName`.

### 4. Release build and measurements (this phase)

- `cargo build --release`: **exit 0**; `target\release\nameshot.exe` = **2,084,859 bytes**,
  built 2026-10-07 18:47:38. No benchmark loop or measurement code exists in the app -
  all numbers come from an external script reading OS process counters.
- Conditions: Windows 10 IoT Enterprise LTSC build 19044 x64, 1920x1200 single monitor,
  interactive GUI session, release exe, app driven via posted/sent messages only
  (no input simulation); idle measured after 8 s warm-up over a 20 s window; memory from
  `PrivateMemorySize64` / `PeakWorkingSet64`; sockets from `Get-NetTCPConnection` /
  `Get-NetUDPEndpoint` filtered by PID.

| State | Private working set | Peak working set | CPU over window | TCP/UDP sockets |
|---|---|---|---|---|
| idle (tray) | 1.6 MB | 8 MB | 0.000 s over 20 s (~0% of one core) | 0 / 0 |
| capture session (overlay) | 19.7 MB | 37.2 MB | n/a (short session) | 0 / 0 |
| editor session | 7.9 MB | 37.2 MB | n/a (short session) | 0 / 0 |
| after session exit | 2.3 MB | 37.2 MB (lifetime peak) | n/a | 0 / 0 |

### 5. No network, no analytics, no hidden history (this phase)

- Dependencies: `cargo tree` -> only `windows 0.62.2` and its sub-crates; no HTTP/socket
  or telemetry crate exists in the graph.
- Code paths: no `connect`/`send`/URL usage in `src/`; the only file writes in the whole
  app are the panic log (`main.rs`) and the settings save (`config.rs::save`).
  Captures are written **only** on explicit Save/Quick save, timestamped, never
  overwritten (existing files get a `_1`, `_2`, ... suffix) - there is no hidden history;
  quick save additionally surfaces as a normal visible file in the chosen folder.
- Runtime: 0 TCP and 0 UDP endpoints owned by the process in idle, overlay, and editor
  states (live, three measurements).

### Actually run and observed (2026-10-07)

| Command | Result |
|---|---|
| `cargo build --release` | **exit 0** (exe 2,084,859 B, 2026-10-07 18:47:38) |
| `cargo check --all-targets` | **exit 0**, no warnings |
| `cargo test` | **exit 0 - 54 passed, 0 failed** (46 unit + 4 encode + 4 redaction) |
| `rustfmt --edition 2024 --check src/win/a11y.rs` | **exit 0** (new file formatted; no repo-wide rewrite) |
| live `ns_p5.ps1` against the release exe | **26/26 PASS** |

Live results (S1 persistence / S2 recovery / S3 measurement + a11y):

- **S1**: OK wrote `format=bmp`, `quick_save=1` to disk; app exited cleanly; after restart
  Settings reopened and showed `combo=2 (BMP)`, `quick=1`, `quality=90`, `hotkey=Insert`;
  clean exit.
- **S2**: deliberately corrupt INI (`version=99`, `hotkey=banana`, `format=tiff`,
  `quick_save=banana`, `launch_at_login=yes`, `jpeg_quality=999`, unknown `telemetry=on`)
  -> recovered to `PNG`, quick off, startup off, `quality=90`, `hotkey=PrintScreen`,
  empty folder; startup box "Capture hotkey unavailable" shown for the conflicted default
  PrintScreen hotkey (the documented fallback path); clean exit.
- **S3**: measurements as in the table above; editor inline text input reports
  `accName=[Text input]`.
- **Restore**: `settings.ini` restored byte-identical to the pre-test baseline
  (hash match); no stray capture files in Pictures; no leftover process.

### Findings during verification (test tooling only - no application defects)

- The tray menu gains an item while `quick_save=1`, shifting menu navigation: opening
  Settings needs 3x Down instead of 2x (an early run pressed Quick save instead and left
  one stray BMP, which was deleted; it also proved Quick save's no-overwrite naming live).
- `GetWindowTextW`/`GetDlgItemTextW` return 0 for edit controls owned by another process;
  `SendMessage(WM_GETTEXT)` returns the real text - test reads use the latter.
- This machine's UIA client reports `ControlType=Pane` for all bridged Win32 controls
  (Notepad's Edit behaves identically) - client quirk, assertions key on `AutomationId`
  and MSAA `accName` instead.

### Exit criteria (Phase 5, original plan)

- [x] Settings survive restart (S1 round-trip).
- [x] Defaults remain privacy-safe (S2 recovery; launch-at-login off; no pixel data in
      the settings file).
- [x] Idle process is quiescent (0 CPU seconds over 20 s, 0 sockets).
- [x] Reported measurements are real and reproducible (external script, conditions and
      exact numbers recorded above; no in-app benchmark).

---

## Phase 6 — Verification, packaging, and delivery (2026-10-07, original plan numbering)

Original plan items: (1) run formatting, linting, all tests, release builds and fix
warnings that indicate correctness/safety/resource problems; (2) review unsafe code,
resource cleanup, hotkey conflicts, clipboard ownership, DPI arithmetic, redaction
export paths; (3) complete README/ARCHITECTURE/BUILD_LOG + a concise manual QA
checklist; (4) separate passed automated/core checks from manual checks still required;
(5) honest final summary — plus the 8-box final acceptance checklist. Windows-specific
execution **was** available on this machine, so every runnable check was run live.

### 1. Release gates (all re-run fresh in this phase)

| Command | Result |
|---|---|
| `cargo build --release` | **exit 0** (4.71 s, cached) — `target\release\nameshot.exe`, 2,084,859 B, built 2026-10-07 18:47:38, unchanged by this phase (no source edits) |
| `cargo test` | **exit 0 — 54 passed, 0 failed** (46 unit + 4 encode + 4 redaction) |
| `cargo check --all-targets` | **exit 0** — 0 errors, 0 warnings |
| `cargo clippy --all-targets` | **exit 0** — `nameshot (lib)` 35 warnings (19 auto-fixable), `nameshot (lib test)` 41 warnings (35 duplicates); 17 distinct warning texts, all style/docs/complexity (see classification below) → nothing matching "correctness, safety, or resource problems" → **no fixes required** |
| `cargo fmt --check` | **exit 1** — 169 diff blocks in 25 pre-existing files; recorded, not reformatted (repo convention: no repo-wide rustfmt rewrite). `src/win/a11y.rs` and `tests/redaction.rs` are individually rustfmt-clean (exit 0), and all files added/edited in later phases stay formatted |

Clippy classification (artifact: `%TEMP%\opencode\p6_clippy.txt`): the 17 distinct
warning texts are `too_many_arguments` ×2 (8/7 and 9/7), `chunks_exact`/`chunks_exact_mut`
with constant size ×2, `type_complexity`, `missing_safety_doc`, an unnecessary same-type
pointer cast, `collapsible_if`, `if_same_then_else`, an unneeded `Some`/`?` combination,
elidable explicit lifetime `'a`, index-only loop variable, `manual_div_ceil`,
`derivable_impls`, immediately-dereferenced reference, `field_reassign_with_default`,
and a no-effect operation. The only unsafe-adjacent two — the pointer cast (no behavioural
effect) and the missing `# Safety` doc section — were reviewed line-by-line and are
benign: all `unsafe` is confined to `win/*`, `capture.rs`, `app.rs` (wndproc/plumbing),
always behind RAII guards, and the OS-free core contains none. Every message is
style/docs/complexity; there are **no correctness, safety, or resource warnings to fix**,
and running `cargo fmt` repo-wide would rewrite 25 untouched files, so it is recorded
instead (per plan wording).

### 2. Production-path review (plan item 2) — no defects found

| Area | Finding |
|---|---|
| unsafe code | Only in `win/*`, `capture.rs`, `app.rs` (wndproc/plumbing); every GDI object/DC/clipboard/hotkey ownership is RAII (`win/gdi.rs`, `ClipGuard`, unregister on exit). OS-free core has zero `unsafe`. |
| resource cleanup | Sessions own buffers; Esc/close/drop frees them (overlay, editor, capture). Phase 5 + 6 live runs both end "no leftover process/files". |
| hotkey conflicts | `RegisterHotKey` error 1409 handled non-fatally (`hotkey_ok=false`, clear message, Settings rebind, tray fallback); no re-registration polling loop anywhere. |
| clipboard ownership | `GlobalAlloc`'d DIB/PNG buffers handed to `SetClipboardData` (system owns on success, freed on failure); `CF_DIB` + registered `PNG` format; open/empty/close guarded. |
| DPI arithmetic | `SetProcessDpiAwarenessContext(PER_MONITOR_AWARE_V2)` before any window (`app.rs:426`); all coordinates physical pixels; overlay spans the virtual screen incl. negative coords. |
| redaction export paths | `do_copy` (`src/editor/mod.rs:1212`), `do_save` (:1231), `quick_save` (`src/app.rs:135`) all call `preview.render(items, None)` → `flatten::apply` → `redact::pixelate`/`solid`; the `preview_incremental_matches_full_flatten` unit test proves preview == full flatten. No other call site reaches the encoders or clipboard (grep of `encode_to_file`/`clipboard::set` call sites). `tests/redaction.rs` (4 tests) proves the flattened-only contract byte-for-byte. |

### 3. Live verification — `ns_p6.ps1`: **31/31 PASS, FAILED=0** (2026-10-07 20:40–20:41)

Single attempt per session, no retries; settings baseline hash-restored; artifact:
`%TEMP%\opencode\p6_run_output.txt` (condensed PASS record) + diagnostic PNGs
(`p6_diag_R*_*.png`, `p6_*_pre*.png`).

| Session | What was driven | Key results |
|---|---|---|
| O1 | hotkey → overlay → **`Esc` cancels the capture session** | overlay gone, app alive, no editor (this closes the last untested capture-path branch) |
| R1 (mosaic) | hotkey → selection drag (500,300)→(1400,850) → Enter → editor → Tab×7+Enter (mosaic) → drag (80,200)→(700,430) → **Ctrl+C then Ctrl+S** → save dialog accepted (Enter posted directly to the dialog hwnd) | copy vs saved PNG **pixel-identical (diffPixels = 0 / 496,451, 901×551)**; mosaic redaction present in both: 90 cells, per-cell dense diff vs pre-capture crop, adjacent-row identity 0.933, only 308 distinct values where the source has 1,910 |
| R2 (solid) | same flow, Tab×8+Enter (solid) | copy vs save **pixel-identical (0 / 496,451)**; solid region fully opaque + uniform: 132,090 px, bbox 595×222 at (61,103) — exactly the dragged rect in image coordinates |
| cleanup | polite `WM_CLOSE` exit after each session | no leftover capture files, `settings.ini` byte-identical to baseline (hash), no process, no `%TEMP%\nameshot_panic.txt` |

Redaction properties were checked against the **pre-capture screen crop**, so the
mosaic/solid assertions prove the exported pixels carry no original content — the
production output path (`do_copy`/`do_save` → flatten → redact → WIC/clipboard), not a
test-only path.

Test-tooling notes (no application defects): driving the editor required posting input
messages rather than synthesizing hardware input, because the machine's operator was
actively using the desktop during runs (physical Space key switches the drag into pan
via `key_down(VK_SPACE)`; another mouse button steals `SetCapture` via
`WM_CAPTURECHANGED`). Save/`Enter` was posted straight to the `#32770` dialog window to
be race-proof against focus changes. Every session verified `settings.ini` restoration
by hash.

### 4. Documentation completed (plan item 3)

- **README**: Phase 6 status row; new *Running* section (package location, extract-and-run,
  **no runtime prerequisites** — DLL import audit below); `cargo build --release` in the
  build commands; *Measured resources* table (Phase 5 numbers + conditions); **10-item
  manual QA checklist**; *Known limitations* (single-monitor machine, multi-monitor/
  mixed-DPI untested, DRM/secure desktop, placeholder icon, unsigned, mosaic ≠ anonymity);
  *Troubleshooting* (hotkey conflict, panic log, paste formats, start-at-login);
  project-layout updated (`a11y.rs`, `os.rs`, `dist/`).
- **ARCHITECTURE**: module-table drift fixed — `main.rs` row now describes only the entry
  point/panic hook, `app.rs` row credits the OS gate/DPI/COM/message loop actually in
  `app.rs`+`os.rs`, `capture/mod.rs`+`GetDIBits` corrected to `capture.rs`+`BitBlt`/`CreateDIBSection`,
  added missing rows (`hotkey.rs`, `output.rs`, `win/a11y.rs`, `settings_ui.rs`), and the
  portability section's `capture/` path corrected.
- **BUILD_LOG**: this entry; Plan reconciliation updated (Phase 6 row, Phase 2 doc-gap
  criterion ticked, Phase 3/4 criteria re-scoped to their real current state, Phase 6
  five items + 8-box checklist ticked with evidence).

### 5. Passed automated/core vs. still manual/unverified (plan item 4)

**Passed and live-verified on this machine** (phases 3, 5, 6): tray lifecycle, hotkey +
conflict path, overlay open/Esc-cancel/drag-select, capture→editor→copy→save (Phase 3
baseline; Phase 6 repeated it with mosaic + solid property checks), settings persistence
+ corruption recovery, accessibility names via MSAA, idle/perf/network measurements,
release gates (54 tests, 0 warnings, clippy/fmt classified).

**Still unverified / manual-only (honestly recorded, none of it claimed):**

1. **Multi-monitor coordinates and mixed-DPI desktops** — the machine has one
   1920×1200 monitor. Design reviewed (virtual-screen bounds, negative coords,
   `PER_MONITOR_AWARE_V2`), never live-tested. Documented in README *Known limitations*
   and the QA checklist.
2. **Live per-tool editor pass** for pen/line/arrow/rect/box/highlight/text and live
   `Ctrl+Z`/`Ctrl+Y` — implemented and unit/integration-tested, but never driven
   interactively end-to-end (original Phase 3/4 criteria, still open above).
3. **DRM/protected content and secure desktop (UAC)** captures — inherent GDI limits,
   not tested.
4. **Code signing / installer** — explicitly out of plan scope; the package carries no
   signing or installer guarantees.

### 6. Packaging (plan title: "packaging and delivery")

- Artifact: **`dist\NameShot-0.1.0-win-x64.zip`** containing exactly:
  `nameshot.exe` (2,084,859 B), `README.md`, `docs\ARCHITECTURE.md`, `docs\BUILD_LOG.md`
  (the zip is built after all documentation edits, so the package carries this entry).
- Executable SHA-256 (both in the repo build and inside the zip):
  `199EDCEC9F5E93C1DD09194F900DAAFB27C0963253E10636ECD744A1F4201E1A`.
- Prerequisites audit (`objdump -p nameshot.exe`): imports only Windows system DLLs
  (KERNEL32/USER32/GDI32/comctl32/dwmapi/uxtheme/shell32/ole32/…) and the inbox
  Universal CRT (`api-ms-win-crt-*`, present since Windows 10). **No libgcc/libwinpthread/
  vcruntime, no WebView2, no .NET, no MSVC redistributable, nothing bundled or installed.**
  (WS2_32.dll appears only as a binding import; the Phase 5 audit found 0 sockets in all
  states and no network code paths.)
- Verification performed: extract zip to a temp dir → SHA-256 of the extracted exe
  **equal** to the repo build → launch the *extracted* copy → main window
  (`NameShot.Main`) found → polite `WM_CLOSE` → process exited (**smoke pass**).
  No installer, no code-signing claim.

### 7. Final acceptance checklist (original plan, verbatim boxes)

- [x] **Native Rust/Win32 app; no Electron, Tauri, WebView, Chromium, Node runtime, or
      background server.** — single dep `windows 0.62.2` (`cargo tree`), plain Win32
      windows + `GetMessage` loop; DLL audit shows no browser/runtime libraries.
- [x] **Tray lifecycle and configurable global capture hotkey work; hotkey conflict does
      not break the app.** — Phase 3 tray live, Phase 5 S1 hotkey rebind persists across
      restart, S2 showed the conflict message with the app still running; Phase 6 ran
      both sessions through the registered hotkey.
- [x] **Region capture, multi-monitor-aware coordinates, Escape cancellation, and
      minimal-resource idle message loop.** — capture/Esc/idle live-verified (Phase 3,
      O1 in Phase 6, idle 0 CPU-s/0 sockets in Phase 5); *multi-monitor coordinates:
      design-reviewed, single-monitor machine — recorded caveat, not live-tested.*
- [ ] **Dark, original, compact editor with core annotations and undo/redo.** — editor
      dark/compact/original with all nine tools implemented and unit/integration-tested;
      mosaic + solid + toolbar navigation live-verified with property checks (Phase 6),
      but no drawing tool and no undo/redo keystroke has ever been driven live end-to-end
      (Phase 3 opened the editor only for copy/save) → **remains the one open box**
      (original Phase 3/4 criteria above).
- [x] **Pixelate and solid redaction applied to the actual flattened copied/saved output;
      automated tests cover this.** — Phase 6: copy == save pixel-identical and redaction
      property-checked in both for both tools; `tests/redaction.rs` 4/4 passing; export
      path audit in §2.
- [x] **Copy and local save work; no default network requests or automatic upload.**
      — Phase 3 + Phase 6 live copy/save; Phase 5: no network crates, no network code,
      0 TCP/UDP endpoints in idle/overlay/editor.
- [x] **Resource use and test coverage are measured and described honestly.** — Phase 5
      measurement table (conditions recorded) + this phase's gates (54 tests, clippy/fmt
      classified with exact counts).
- [x] **Documentation provides reproducible build, run, and manual verification steps.**
      — README (commands, Running section, QA checklist, troubleshooting), ARCHITECTURE
      (module table now matches the code), this log (per-phase evidence).

### 8. Honest final summary (plan item 5)

NameShot was **implemented, tested, run, measured and packaged** on this machine: a
single 2.08 MB native Rust/Win32 exe (no runtime install) with tray + configurable
hotkey, virtual-screen region capture with Esc-cancel, a dark editor with nine tools
including mosaic/solid redaction, clipboard (`CF_DIB`+PNG) and native-dialog save with
PNG/JPEG/BMP, versioned crash-safe settings, accessibility names, and zero network code.
Evidence: 54 automated tests green, 0 compiler warnings, live phases 3/5/6 at
50+26+31 checks with only original-Phase-3-style gaps left (per-tool live editor pass,
multi-monitor/mixed-DPI), measurements as in the Phase 5 table, package verified by
hash + smoke run. **Not claimed:** perfect optimization, universal compatibility,
multi-monitor/DPI coverage, code signing, or an installer; two acceptance criteria
(original Phase 3 live per-tool pass and its `Ctrl+Z`/`Ctrl+Y` live check) remain open
and are listed as such in "Original acceptance criteria — final status" above.

### Exit criteria (Phase 6, original plan)

- [x] Formatting/lint/tests/release build run; only style-level lint findings remain
      (classified, nothing correctness/safety/resource-related to fix).
- [x] unsafe/resource/hotkey/clipboard/DPI/redaction review completed — no defects found.
- [x] README, ARCHITECTURE, BUILD_LOG completed + concise manual QA checklist added.
- [x] Passed automated vs. still-manual split documented (§5).
- [x] Honest final summary (§8) + 8-box acceptance checklist with evidence (§7).

## Phase A — Inline-editor corrective task, diagnosis (2026-10-08)

Scope: diagnose the two release-blocking UX problems that triggered this corrective
task — (1) capture → annotate flow interrupted by a separate editor window,
(2) screenshot flickers/blinks on tool selection/use — **before** implementing the
inline-editing redesign (Phase B). Live runs used the release build
(`target\release\nameshot.exe`), `PostMessageW`-only driving, passive
`CopyFromScreen` sampling, and `settings.ini` backup/restore verified by hash after
every run. **Caveat:** the operator actively used the desktop during the runs
(moving windows, wheel-zooming, drawing); several early observations were therefore
environment artifacts, listed under "Ruled out / corrected" below.

### Problem 1 — separate editor window interrupts the flow (LIVE + CODE)

- Code: `overlay.rs` `confirm()` :576-612 calls `DestroyWindow` (:609) and then
  `editor::open` (:611); `editor::open` (`editor/mod.rs:270-366`) creates a brand-new
  `NameShot.Editor` window (`CreateWindowExW` :336, `ShowWindow(SW_SHOW)` :366).
  The overlay is destroyed before the editor exists → a desktop gap is structurally
  unavoidable with this design.
- Live: run 2 window timeline — editor hwnd appears ≤ 12 ms after overlay death,
  but the window is **not visible until ~305 ms**, i.e. the desktop (and whatever the
  operator had focused) is exposed for 50–300+ ms between "overlay gone" and
  "editor painted". Hwnd-level gap measured in run 1: 1.8 ms (destroy → new hwnd).
- Verdict: **confirmed**. Fix direction for Phase B: no window transition at all —
  edit inside the existing overlay (`Phase::{Selecting, Editing}`).

### Problem 2 — flicker/blink on tool use (LIVE + CODE)

- Code: `editor/mod.rs` `paint()` :964-1068 paints **directly to the visible DC in
  phases** with no double buffering: `fill_solid(tb)` → `fill_solid(status)` →
  `fill_solid(canvas)` → `preview.render()` → `StretchDIBits` → border → status →
  toolbar. `WM_MOUSEMOVE` during a drag calls `invalidate_canvas` per move event
  (~60 Hz), so every drawing gesture re-runs the whole fill→render→blit pipeline
  on screen; `commit_any_text` / undo / redo / `WM_APP_STATUS` invalidate the whole
  client (single text-commit frame captured in run 1 showed background-only paint).
- Live (instrumented release build, run 3): blank-canvas frames (canvas region
  **exactly** the `CANVAS` color, 590,611 px = 973×607, status still correct) captured
  in 5 separate tool-click probes (`click_Mark` ×2 consecutive, `click_Mosaic`,
  `click_Redact`, `click_Pen` ×2, earlier runs `click_Line` ≥ 543 ms, `click_Box`,
  `fx2_text_commit_0`). An earlier sequence of consecutive blank frames during a pen
  drag matched a sustained ~60 Hz invalidation storm (paint phases observable for
  most of each frame's time).
- Decisive instrumented run: `paint()` logged `StretchDIBits` return, `dw/dh`,
  image-vs-canvas overlap, `zoom/view/canvas/rcPaint` on every anomaly, plus
  `TOOL` state snapshots on every tool command — **11/11 tool clicks with identical,
  correct state (`fit=true`, `zoom=1.0436`, `view=(-15.69,-15.33)`, canvas
  `(0,76,973,683)`), 0 blit failures, 0 skipped blits, 0 off-image cases** — while
  blank frames were still captured. Conclusion: the app never painted a
  fill-without-image state to completion; the screen showed the **intermediate
  phase of an in-progress repaint** (canvas `fill_solid` written, blit not yet run),
  sampled by the concurrent screen capture / DWM composition, and the missing image
  persists on screen until the next canvas-region invalidation (tb/status-only
  paints never refresh it) — i.e. exactly the reported "screenshot blinks when
  picking/using a tool".
- Verdict: **confirmed root cause = single-buffered, phased direct-to-screen painting
  amplified by per-mousemove full-canvas invalidation**. Fix direction for Phase B:
  retained offscreen backbuffer, compose fill+image+border+status+toolbar in it,
  present with a single `BitBlt` per paint; region-aware invalidation.

### Ruled out / corrected (with evidence)

- **GDI-object quota exhaustion** (candidate cause of intermittent blit failure):
  brush/pen lifecycles audited — `gdi.rs` `fill_solid` (create→FillRect→delete),
  `toolbar.rs` `Content::Dot` (select→Ellipse→restore→delete :326-341) are balanced;
  the instrumented run measured **0 blit failures** anyway. Not the cause.
- **Bad view/zoom state** (huge `view` offset blanking the canvas): instrumented
  state logs identical and correct at all 11 tool clicks; `clamp_view` (:195) sound.
  Not the cause.
- **Operator wheel-zoom false positives**: run-1 "anomalies" at cv≈498k were the
  image at 43% zoom (1.04×0.8⁴) from the operator zooming — not a defect.
- **Fresh-tray CPU regression**: `CPU_TRAY_FRESH_10s=0.000 s`; the earlier 2.234 s
  reading was polluted by test-driven activity. Not a defect.
- **Run-1 multi-second "editor missing"**: operator's other window was on top
  (z-order theft); the app-side gap is the 50–300 ms paint latency above.
- **`FLASH_DELTAS=0` in run 2**: test-harness scoping bug (function-local
  `$flashLog` shadow), fixed in run 3 with `$script:anoms`; run-3 flash counting is
  the trustworthy one.

### Instrumentation note (temporary, reverted)

A throwaway build added `dbg_log` anomaly lines in `paint()`/`command(Tool)`
writing to `paint_debug.log`. After the decisive run, `src\editor\mod.rs` was
restored from a byte-identical backup (verified: grep for `dbg_log|paint_debug`
across `src` → no matches), `paint_debug.log` deleted, and `cargo build --release`
re-run clean (exe timestamp 2026-10-08 11:41). The repository and release build
contain no instrumentation.

### Exit criteria (Phase A)

- [x] Problem 1 reproduced live with measured timing; code cause identified.
- [x] Problem 2 reproduced live (blank/fill-phase frames); code cause identified
      and decisive instrumented run distinguishes "never painted wrong" from
      "painted wrong".
- [x] Alternative hypotheses audited and ruled out with evidence.
- [x] Diagnosis recorded here separating live observations from code-level
      reasoning; false positives and harness bugs explicitly corrected.
- [x] Repository reverted to pre-instrumentation state; release build clean.

## Phase B — In-overlay editing, no separate window (2026-10-08)

### Implemented (code)

- `overlay::Phase::{Selecting, Editing}`: `confirm()` no longer destroys the
  overlay. It crops the hotkey-time capture (`ov.frame`) to the selection,
  builds `EditSession::new(cropped, RECT canvas, (vs.w, vs.h), secure)` and
  flips the same window into `Phase::Editing` — the HWND never changes
  (live-verified: same overlay hwnd across Enter), the desktop is never
  exposed, and the capture is never repeated.
- `Backbuf` (`MemDc` + `OwnedGdi<HBITMAP>` + previous-object restore in `Drop`,
  field order mem→bmp): `paint()` composes fill → image → border → status →
  toolbar **into the backbuffer, clipped to `ps.rcPaint`**, then presents with
  a single `BitBlt`. This removes the fill-without-image intermediate state
  from the screen (Phase A root cause 2).
- `EditSession::apply(cmd) -> Redraw::{Chrome,Document}`: Tool/Color/Width are
  `Chrome`-only — the canvas region is **never invalidated by a tool click**,
  so the frozen selection cannot blink (unit-tested:
  `color_and_width_selection_are_chrome_only`,
  `tool_changes_never_touch_the_document`).
- Text tool: child `EDIT` subclassed (`edit_proc`, `SUBCLASS_ID 0x454F`),
  accessible name via `win::a11y::set_name` (edit.rs:1079), Enter commits,
  Esc cancels, destroyed on WM_DESTROY.
- Close path: `try_close` = commit pending text → `dialog::confirm` only when
  `history.is_dirty()` (title "Discard capture?") → `DestroyWindow`.
  WM_CLOSE and `exit_app` route through the same dirty check. All dialog call
  sites drop the session borrow first (audit, Phase D).
- Keyboard (editing): Esc close, Enter commit/confirm, `Ctrl+Z/Y/C/S`,
  Tab focus cycle across the rail/strip.
- `restart()` (R, selecting phase) now recreates the backbuffer when the
  virtual screen size changes (Phase D finding, fixed in this phase's code).
- `editor::open` retired from the flow: **0 callers** (grep `editor::open(`),
  kept as code. The editor window cannot appear in the current flow (also
  live-observed: "editor window never appeared").

### Actually run and observed

- `cargo build --release` → **exit 0, 0 warnings** (final state).
- `cargo test --release` → **exit 0; 62 passed, 0 failed** (54 lib incl. 8
  `overlay::edit` tests + 4 + 4 integration).
- Live harness `ns_pb1.ps1` (PostMessage/keybd, no operator input required for
  the written assertions) iterated over 3 runs. Passing assertions in the last
  run: main+overlay open, **same overlay hwnd across Enter**, rail/strip drawn,
  frozen canvas image stable, line/pen commits produce pixel diffs, Copy puts a
  **real image on the clipboard**, dirty-Esc raises the discard dialog,
  **No keeps the overlay with canvas intact (diff=0)**, undo restores the base
  exactly, child EDIT created/destroyed, editor window never appears, app
  alive after overlay close, settings restored.
- The same run carried 7 unexplained artifacts (an extra committed line and a
  mosaic rect not in history; text typing dropped). They are recorded as
  **unresolved** — the run was contaminated by concurrent operator input
  (foreground-lock stolen the keystrokes at least once), so it cannot
  distinguish app defects from test interference. A hands-off re-run is
  **deferred at the user's request** ("Later — I'll tell you when to run").

### Exit criteria (Phase B)

- [x] Enter keeps one continuous overlay window; no desktop exposure code path.
- [x] Tool/color/width clicks cannot invalidate the canvas (unit-tested).
- [x] Build clean, all tests green.
- [ ] Clean-machine live re-run of `ns_pb1.ps1` with all assertions passing
      (deferred; harness ready).

## Phase C — Overlay UI polish (2026-10-08)

### Implemented (code)

- **Hover tooltips** rendered in the status chip: hovering any rail/strip
  button replaces the chip text with `Label: hint` (e.g. `Mosaic: Pixelate a
  region`, `Undo: Undo last change (Ctrl+Z)`, `Color: Red`,
  `Stroke width: 4 px`); leaving the button restores the transient message or
  the image dimensions. Implementation: `strings.tip_*` + `color_names`,
  `tip_for(Cmd)`, `hover_tip` field, chip precedence
  (hover > message > dims), status-rect-only invalidation on change — **no
  floating tooltip windows, no timers, no extra repaints** (constraint
  compliant).
- Shortcuts are advertised only where wired (`Ctrl+Z/Y/C/S`, `Esc`) — enforced
  by the new unit test `tips_cover_every_button_with_shortcuts_only_where_wired`.
- Pre-existing chrome verified as already covering the rest of the plan:
  hover/selected/disabled/focus-ring states via `toolbar::paint`, all nine
  tools (mosaic + solid included) on the rail, accessibility name on the text
  `EDIT`. Deliberate scope decisions: no icon redesign (text labels are
  feature parity with the previous editor toolbar) and no pressed state
  (the retired editor window had none either). Zoom/pan exists only in the
  retired editor window — now documented as a known limitation in README.

### Actually run and observed

- `cargo build --release` → exit 0; `cargo test --release` → 62 passed
  (incl. the new tip test); `cargo clippy` → exit 0, baseline unchanged.
- Visual appearance of the new chip text: not yet eyeballed (live re-run
  deferred with Phase B).

## Phase D — Constraint audit (2026-10-08)

Every plan constraint re-checked against the final code; grep evidence where
noted, manual reading where a grep cannot prove absence:

- [x] **No timers/polling/sleeps** — grep `SetTimer|WM_TIMER|Sleep(|thread::sleep`
      over `src` → 0 matches.
- [x] **No layered/composited windows** — grep `WS_EX_COMPOSITED|WS_EX_LAYERED|
      UpdateLayeredWindow` → 0 matches.
- [x] **No instrumentation residue** — grep `dbg_log|paint_debug|eprintln!|dbg!(|
      println!(` → 0 matches.
- [x] **Single-buffered painting removed** — every paint goes through `Backbuf`
      (compose → one `BitBlt`); fallback path only if backbuf creation failed.
- [x] **No session borrow held across message-pumping calls** — read every
      dialog/clipboard/capture call site: `command()` dispatches Copy/Save/Close
      before borrowing; `do_copy`/`do_save` extract the frame in a scoped borrow
      and call `copy_image`/`save_image`/`error_box` after it is dropped;
      `try_close`, WM_CLOSE, `confirm()`, `restart()`, `quick_save()`,
      `exit_app()` all drop borrows first (e.g. `confirm()` `drop(b)` before
      `warn_box`, mod.rs:772/785/792).
- [x] **Region-limited invalidation** — editing-phase invalidations are rect-scoped
      (`invalidate_canvas/bar/status/btn`, `inv()`); full-window invalidates exist
      only at phase transitions and `restart()` (bounded events, not mousemove).
      Selecting-phase drags use `invalidate_region` (union of old/new band).
- [x] **GDI lifecycles** — `Backbuf::Drop` restores the previous object before
      `DeleteDC`/`DeleteObject`; `MemDc`/`OwnedGdi`/`SelectedObject` RAII;
      `SelectObject` restore pairs verified at every ad-hoc site.
- [x] **`paint_face` shared** with `settings_ui` (settings_ui.rs:509 →
      toolbar.rs:359) — untouched.
- [x] **No nested app message loops** — dialogs are system modal boxes only.
- [x] **`editor::open` retired** — 0 callers (grep).
- [x] **Backbuffer sizing on restart** — fixed in Phase B (was stale after a
      virtual-screen size change).

## Phase E — Automated gates (2026-10-08)

| Gate | Command | Exit | Result |
|---|---|---|---|
| Release build | `cargo build --release` | 0 | 0 warnings |
| Unit + integration tests | `cargo test --release` | 0 | **62 passed, 0 failed** (54 lib + 4 + 4) |
| Clippy | `cargo clippy --release --all-targets` | 0 | 35 lib warnings = pre-existing baseline (41 lib-test incl. 35 duplicates) |
| Format check | `cargo fmt --check` | 1 | pre-existing, repo-wide (file was never rustfmt-formatted; no repo-wide fmt run per constraints) |
| Instrumentation / timers / layered grep | see Phase D | — | 0 matches each |
| Docs consistency | README flow text + QA checklist + status row | — | updated in Phase F |

**Live QA (Phase E, second half): not run in this phase.** The rerun of
`ns_pb1.ps1` is deferred at the user's explicit request; nothing in this log
claims live passage for Phases B–C beyond the partially-passing contaminated
run recorded in Phase B.

## Phase F — Documentation (2026-10-08)

- **README.md**: intro and Capture/Editing feature bullets rewritten for the
  in-overlay flow (Enter → edit in place, chip tooltips, shortcuts), QA
  checklist lines updated, zoom/pan added to *Known limitations*, status table
  gained the corrective-task row, project-layout note that the separate editor
  window exists but is no longer opened.
- **BUILD_LOG.md**: Phases B–F recorded (this section).
- **Packaging: untouched.** `dist\NameShot-0.1.0-win-x64.zip` and its hashes
  come from the previous delivery phase and were deliberately not rebuilt;
  the zip therefore still contains the pre-Phase-B exe. A re-package decision
  belongs to the user's review step, not to this corrective task.

### Exit criteria (Phases B–F, this corrective task)

- [x] Enter no longer destroys/recreates the window (code + partial live proof).
- [x] Tool clicks cannot repaint the canvas (unit-tested; single BitBlt present).
- [x] All automated gates green (table above).
- [x] Constraint audit clean (Phase D).
- [x] Docs reflect the shipped behaviour.
- [ ] **Live clean-machine QA re-run** (deferred by user; harness ready).
- [ ] **Re-package** (explicitly out of scope until user review).

## Phase G - Text-edit focus-loss survival + fail-closed QA harness (2026-10-08)

Driver: the first full live QA run (Phase B/E rerun, 2026-10-08 14:13) failed at
the text step (`typed text reaches EDIT ('')`), and the follow-up diagnostic run
localized the cause: an external window stole the foreground while the text box
was focused, the child EDIT received `WM_KILLFOCUS`, and `edit_proc` reacted by
commiting-and-destroying the box; focus later returned to NameShot, so the QA
foreground guards passed while the EDIT was already gone and the typed keys were
lost. A second, independent defect was found in the QA harness itself: PowerShell
guards that returned @(log-string, $false) made every `if` clause evaluate TRUE
(non-empty array), so keystrokes were injected despite a failed guard.

### Production changes (src/overlay/edit.rs, src/overlay/mod.rs, src/app.rs)

- `EditSession::on_text_focus_lost()` (deliberately empty policy hook),
  `EditSession::commit_pending_text()` and `EditSession::cancel_pending_text()`:
  the text lifecycle is now explicit-action driven and unit testable.
- `edit_proc` `WM_KILLFOCUS` no longer commits/destroys the EDIT: the draft and
  the box survive focus moving outside NameShot (and transitions to other
  NameShot controls); the message is forwarded to `DefSubclassProc` because the
  control now outlives the focus loss. Focus is never stolen back.
- Explicit commits only: `Enter` (in the box), toolbar/action commands
  (tool/colour/width, `Copy`, `Save`), `try_close`/`Cmd::Close`, overlay
  `WM_CLOSE`, tray *Quick save* and tray *Exit* (the last three so the dirty
  prompt and exported image account for the draft). `Esc` in the box cancels.
- Tests added (4): `external_focus_loss_preserves_the_pending_draft`,
  `app_owned_focus_transition_keeps_the_draft_until_explicit_commit`,
  `explicit_commit_places_trimmed_text_and_empty_box_closes_free`,
  `cancel_discards_the_draft_without_touching_history`.

### Harness changes (%TEMP%\opencode, not in repo)

- New shared `ns_guards.ps1`: `Set-StrictMode`, self-contained `PbG` P/Invoke
  (foreground, foreground-thread `hwndFocus`, window titles), `Assert-Fg`,
  `Assert-FgFocus`, `Invoke-KeyGuarded`. Every guard returns EXACTLY ONE
  `[bool]`; all logging goes through `Write-Host` so it can never pollute a
  captured result; `Invoke-KeyGuarded` blocks injection on non-boolean/null/
  `$false`/empty-guard results (fail closed).
- `ns_pb1.ps1`: strict mode; all four real-keystroke sites (Ctrl+Z, dialog N,
  typing Hola, Enter) routed through `Invoke-KeyGuarded`; typing/Enter require
  `hwndFocus == child EDIT`, Ctrl+Z requires `hwndFocus == overlay root`;
  artifacts uniquely timestamped (`qa_<stamp>_*.png`, guard log
  `pB_qa_<stamp>.log`); all output switched to `Write-Host`.
- New `ns_guards_test.ps1`: static failure-case coverage (fg mismatch, focus
  mismatch, zero focus, historical array return, null, empty guard list, later
  guard failing) - each must yield a single `[bool] $false` and must not run
  the action. Non-interactive: counters only, no keybd_event, no clipboard,
  no NameShot process.

### Gates (this phase)

| Gate | Command | Exit | Result |
|---|---|---|---|
| Tests | `cargo test` | 0 | **66 passed, 0 failed** (58 lib incl. 4 new + 4 + 4) |
| Release build | `cargo build --release` | 0 | 0 warnings |
| Clippy | `cargo clippy` | 0 | 35 lib warnings = pre-existing baseline (0 in edit.rs) |
| Guard tests | `ns_guards_test.ps1` | 0 | **GUARD_TESTS=PASS** (26/26) |
| Harness parse | PowerShell AST, 3 scripts | 0 | 0 parse errors |
| Harness gate smoke | `ns_pb1.ps1` (no -ConfirmClipboard) | 2 | aborts before any side effect |
| Live QA | - | - | **NOT run; remains FAILED/unverified** |

**Status: text tool and full live QA remain UNVERIFIED.** This phase ran only
non-interactive automated tests. Live QA and packaging stay blocked pending the
user's review of this report and an explicit go-ahead.

## Phase H - Auto-close capture session: copy/save close, no discard prompts (2026-10-08)

Driver: user feature request — a capture session must end itself when the
user's intent is fulfilled: Copy closes only after the image really landed on
the clipboard, Save closes only after the bytes were written, and every
explicit close (Close button, `Esc`, `WM_CLOSE`, tray Exit) discards
immediately **without** the "Discard capture?" dialog. A failed copy, a
cancelled Save-As or a write error keeps the session open behind an in-app
error. No changes to hotkey, startup, settings, network or packaging.

### Interim context: authorized live run 20261008_163933 (harness workstream)

Between Phase G and this phase, the QA-harness workstream (fail-closed
guards, SMT proof) performed one authorized live run, stamp
`20261008_163933`, result **FAILED (23/10 as recorded by the run host)**.
Artifacts preserved in `%TEMP%\opencode\`: `pB_qa_20261008_163933.log`
(guard log), `pB_zdiag_20261008_163933.log` (window snapshots),
`qa_20261008_163933_pB_*.png` (step screenshots),
`pB_settings_backup_20261008_163933.ini`. Observable failure: `Esc` opened
the *Discard capture?* dialog (`zdiag: dialog=... above=['D']`) while the
foreground stayed the overlay, so the guarded `N` keystroke was blocked (fg
mismatch) and every later guarded key (Ctrl+Z, typing) was blocked — the run
aborted. This phase removes that dialog from the product entirely, which
also makes the harness's discard-dialog step obsolete.

### Design: one close policy (src/session.rs, new)

Pure module with no window types, exercised directly by tests:

- `Route`: `Copy{ok}`, `Save(SaveOutcome)` (`Saved`/`Cancelled`/`Failed`),
  `Close`, `TextCancel`, `Exit` — every way a session can end.
- `plan(route, session_open) -> Plan` (`KeepOpen`, `CancelTextDraft`,
  `CloseSession`, `Exit`): copy/save close only on success; `Close` always
  discards; `TextCancel` never touches the session; with no session open
  every route is a no-op except `Exit`, which still quits.
- `close_target(session_open, window_alive) -> CloseAction` (`Nothing`,
  `Destroy`, `ClearStale`): the idempotency table — a second finalize sees
  `(false, false)` and does nothing, so window and record are released
  exactly once.

Callers: `overlay::apply_route` / `editor::apply_route` plan and finalize;
`overlay::close_session` / `editor::close_session` run `close_target` against
the live record (`IsWindow` check, then `DestroyWindow` or stale-record
clear). No prompts, no `SetForegroundWindow`, no focus stealing;
`WM_DESTROY` still drops the record together with its child EDIT, fonts and
backbuffer.

### Production changes

- `src/session.rs` (new): policy + 9 state-machine tests.
- `src/lib.rs`: `pub mod session`.
- `src/overlay/mod.rs`: `close_session`/`apply_route`; `WM_CLOSE`,
  Selecting-phase `Esc`, editing-phase `Esc` and the toolbar Close command
  all route through the policy; `editing_dirty`/`confirm_discard` (the Yes/No
  prompt path) deleted; `edit::on_key` no longer takes the hwnd.
- `src/overlay/edit.rs`: Copy/Save close **after** clipboard/file success
  (the tray balloon replaces the status chip, which dies with the window);
  every failure/cancel outcome also routes through the policy (KeepOpen by
  design); `try_close`/`set_status` deleted; `Esc` in the focused text box
  cancels the draft only (`plan(TextCancel, open) == CancelTextDraft`), so
  the next `Esc` reaches the overlay and closes the session.
- `src/editor/mod.rs` (separate window, unreachable from the current flow):
  same contract — commit-before-copy/save in the toolbar command path,
  balloon + close on success, `close_session`/`apply_route`;
  `try_close`/`set_status` deleted.
- `src/app.rs`: tray **Exit** runs `apply_route(Exit)` then destroys the
  windows (no dirty check, no prompt); *Quick save* traces `Route::Save` on
  success **and** failure for whichever session's image it wrote (inline
  overlay frame or legacy editor frame); a fresh desktop capture closes
  nothing.
- `src/strings.rs`: `discard_title`/`discard_msg` removed;
  `win::dialog::confirm` remains as a utility but is no longer called.
- Annotation tools untouched: they never close the session.

### Routes after this phase

| Route | Result |
|---|---|
| Toolbar Copy / `Ctrl+C`, clipboard write ok | balloon + close |
| Copy failure (clipboard error) | in-app error, session open |
| Toolbar Save / `Ctrl+S`, file written | balloon + close |
| Save-As cancelled / write failed | session open (in-app error on failure) |
| Close button, `Esc` (no text box), `WM_CLOSE` | immediate discard, no dialog |
| `Esc` in the focused text box | draft cancelled, session open |
| Tray Exit | closes session (no prompt), then quits the app |
| Quick save of open session work | `Route::Save` traced; closes only on success |
| Annotation tools (pen ... solid) | never close |
| Second finalize (double click, late message) | no-op (`close_target` table) |

### Tests added (11; 66 -> 77 total)

- `src/session.rs` (9): copy/save/close/text-cancel/exit matrices, no
  failure route ever closes, `close_target` idempotency table, exactly-once
  finalize lifecycle, exhaustive full-route matrix (Exit-without-session is
  the documented exception).
- `src/overlay/edit.rs` (2): `committed_text_renders_into_the_exported_frame`
  (GDI glyphs land in `output_frame`, source bitmap immutable) and
  `solid_redaction_covers_committed_text_in_the_exported_frame`
  (redaction flattens over committed text through the real export path).

### Gates (this phase)

| Gate | Command | Exit | Result |
|---|---|---|---|
| Format | `cargo fmt --check` | 1 | pre-existing: 198 hunks crate-wide; **0 in the new `session.rs`** and none of this phase's added lines flagged (flagged hunks in touched files are pre-existing lines/import order) |
| Tests | `cargo test` | 0 | **77 passed, 0 failed** (69 lib incl. 11 new + 4 + 4) |
| Check | `cargo check --all-targets` | 0 | 0 errors, 0 warnings |
| Clippy | `cargo clippy` | 0 | 35 = pre-existing baseline (0 from this phase's code) |
| Release build | `cargo build --release` | 0 | 0 warnings |
| Live QA | - | - | **NOT run; blocked pending user approval** |

### Docs and follow-ups (this phase)

- `README.md`: editing bullet rewritten (auto-close + tray balloon, immediate
  discard without confirmation, text-box `Esc` semantics) and the QA
  checklist item rewritten (the old "`Ctrl+C` then `Ctrl+S` pixel-identical"
  sequence is impossible once Copy closes the session).
- `docs/ARCHITECTURE.md`: no change needed (already describes save-and-close).
- Harness follow-up: `ns_pb1.ps1` still expects the discard dialog and an
  open overlay after copy — it must be updated before the next live run
  (harness lives outside this repository and was not touched this phase).

**Status: feature implemented and unit-verified; live QA not run.** Packaging
and any live/clipboard checks remain blocked pending explicit user approval.
